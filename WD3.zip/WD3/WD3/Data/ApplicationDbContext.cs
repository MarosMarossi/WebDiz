﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using WD3.Models;

namespace WD3.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<WD3.Models.Book> Book { get; set; } = default!;
        public DbSet<WD3.Models.Author> Author { get; set; } = default!;
        public DbSet<WD3.Models.Category> Category { get; set; } = default!;

    }
}
