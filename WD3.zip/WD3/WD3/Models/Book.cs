﻿/*
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace WD3.Models
{
    public class Book
    {
        [Key]
        public int BookId { get; set; }
        [Required]
        [Display(Name = "Názov knihy")]
        public string Title { get; set; }

        // [Display(Name = "Autor knihy")]
        // public string Author { get; set; } foreign key
        // [Display(Name = "Kategoria")]
        // public string Category { get; set; } foreign key
        //  [ForeignKey("Author")]
        //  public int AuthorId { get; set; }

        //  [ForeignKey("Category")]
        // public int CategoryID { get; set; }
        [Required(ErrorMessage = "Zadaj Autora")]
        [Display(Name = "Autor")]
        [ForeignKey("Author")]
        public int AuthorId { get; set; }

        public virtual Author Author { get; set; }

        [Required(ErrorMessage = "Zadaj Kategóriu")]
        [Display(Name = "Kategória")]
        [ForeignKey("Category")]
        public int CategoryID { get; set; }
        [Display(Name = "Kategória")]
        public virtual Category Category { get; set; }

        [Required]
        [DataType(DataType.Currency)]
        [Column(TypeName = "money")]
        [Display(Name = "Cena")]
        public decimal Budget { get; set; }

        [Display(Name = "Fotografia")]
        public string? ImageName { get; set; }
    }
}




*/

/*
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace WD3.Models
{
    public class Book
    {
        [Key]
        public int BookId { get; set; }
        [Required]
        [Display(Name = "Názov knihy")]
        public string Title { get; set; }

        // [Display(Name = "Autor knihy")]
        // public string Author { get; set; } foreign key
        // [Display(Name = "Kategoria")]
        // public string Category { get; set; } foreign key
        //  [ForeignKey("Author")]
        //  public int AuthorId { get; set; }

        //  [ForeignKey("Category")]
        // public int CategoryID { get; set; }
        [Required(ErrorMessage = "Zadaj Autora")]
        [Display(Name = "Autor")]
        public Author Author { get; set; }
        [ForeignKey("Author")]
        public int AuthorId { get; set; }

        [Required(ErrorMessage = "Zadaj Kategóriu")]
        [Display(Name = "Kategória")]
        public Category Category { get; set; }
        [ForeignKey("Category")]
        public int CategoryID { get; set; }

        [Required]
        [DataType(DataType.Currency)]
        [Column(TypeName = "money")]
        [Display(Name = "Cena")]
        public decimal Budget { get; set; }

        [Display(Name = "Fotografia")]
        public string? ImageName { get; set; }
    }
}
*/

/**/
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Net.NetworkInformation;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace WD3.Models
{
    public class Book
    {
        [Key]
        public int BookId { get; set; }
        [Required]
        [Display(Name ="Názov knihy")]
        public string Title { get; set; }

        // [Display(Name = "Autor knihy")]
        // public string Author { get; set; } foreign key
        // [Display(Name = "Kategoria")]
        // public string Category { get; set; } foreign key
        //  [ForeignKey("Author")]
        //  public int AuthorId { get; set; }

        //  [ForeignKey("Category")]
        // public int CategoryID { get; set; }

        // = null!  Neviem co to robi ale funguje to ked to tam je a nechcem sa toho dotykat

        [Required(ErrorMessage ="Zadaj Autora")]
        [Display(Name = "Autor")]
        public int AuthorId { get; set; }
        [ValidateNever]
        [Display(Name = "Autor")]
        public virtual Author Author { get; set; } = null!;

        [Required(ErrorMessage = "Zadaj Kategóriu")]
        [Display(Name = "Kategória")]
        public int CategoryID { get; set; }  //POZOR NA ID je velkym oops
        [ValidateNever]
        [Display(Name = "Kategória")]
        public virtual Category Category { get; set; } = null!;


        [Required]
        [DataType(DataType.Currency)]
        [Column(TypeName = "money")]
        [Display(Name = "Cena")]
        public decimal Budget { get; set; }

        // [Required]
        [Display(Name = "Zdroj")]
        public string? Source { get; set; } = "nic";

        [Display(Name = "Fotografia")]
        public string? ImageName { get; set; } = "nic";





    }
}
