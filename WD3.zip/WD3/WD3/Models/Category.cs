﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace WD3.Models
{
    public class Category
    {
        public int CategoryId { get; set; }
        [Required]
        [Display(Name = "Názov kategórie")]
        public string CategoryName { get; set; } = string.Empty;
        [Display(Name = "Popis kategórie")]
        public string Description { get; set; }
        [ValidateNever]
        public virtual ICollection<Book> Books { get; set; }
    }
}
